package com.prototype.auditwebportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditWebPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
