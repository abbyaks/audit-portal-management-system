package com.prototype.auditseverity.service;

public interface TokenService {

	Boolean checkTokenValidity(String token);

}
